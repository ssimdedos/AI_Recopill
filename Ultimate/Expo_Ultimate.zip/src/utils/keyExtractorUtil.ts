// key extractor temporary
const keyExtractoUtil = (item: any, index: number) => index.toString();
export default keyExtractoUtil;

import { IAnalytic } from './types';

export const data_analytics: IAnalytic[] = [
  {
    image:
      'https://user-images.githubusercontent.com/42206067/228125675-1655fbe4-296a-4eae-839c-4c4cea61fe04.png',
    title: 'Pending Order',
    number: 268,
  },
  {
    image:
      'https://user-images.githubusercontent.com/42206067/228125677-410e082d-301a-40e2-adab-a128de54700a.png',
    title: 'Shipping',
    number: 57,
  },
  {
    image:
      'https://user-images.githubusercontent.com/42206067/228125682-ba26315b-986a-476d-b707-1ac190bc18f7.png',
    title: 'Pending Order',
    number: 268,
  },
  {
    image:
      'https://user-images.githubusercontent.com/42206067/228125684-c3b50ed4-f3a1-4936-9a19-818184b488fd.png',
    title: 'Shipping',
    number: 57,
  },
];

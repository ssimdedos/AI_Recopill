export interface IProduct {
  image: string;
  name: string;
  amount: number;
  rate: number;
}

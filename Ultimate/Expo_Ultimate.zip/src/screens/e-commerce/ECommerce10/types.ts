export interface IProduct {
  image: string;
  name: string;
  min_price: number;
  max_price: number;
  description: string;
  color: string;
}

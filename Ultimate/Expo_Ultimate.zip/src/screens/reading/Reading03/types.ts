export interface IPost {
  image: string;
  title: string;
  date: string;
  description?: string;
}

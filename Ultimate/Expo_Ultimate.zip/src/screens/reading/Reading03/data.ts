import { IPost } from './types';

export const data_banner: string[] = [
  'https://user-images.githubusercontent.com/42206067/232100766-f7d49a4b-c5b4-4e9e-aa83-0ef1c79d33b3.png',
  'https://user-images.githubusercontent.com/42206067/232100766-f7d49a4b-c5b4-4e9e-aa83-0ef1c79d33b3.png',
  'https://user-images.githubusercontent.com/42206067/232100766-f7d49a4b-c5b4-4e9e-aa83-0ef1c79d33b3.png',
  'https://user-images.githubusercontent.com/42206067/232100766-f7d49a4b-c5b4-4e9e-aa83-0ef1c79d33b3.png',
  'https://user-images.githubusercontent.com/42206067/232100766-f7d49a4b-c5b4-4e9e-aa83-0ef1c79d33b3.png',
  'https://user-images.githubusercontent.com/42206067/232100766-f7d49a4b-c5b4-4e9e-aa83-0ef1c79d33b3.png',
];

export const data_post: IPost[] = [
  {
    image:
      'https://user-images.githubusercontent.com/42206067/231991495-9ba089d1-40ca-4900-b131-3e4e26e6cd0a.png',
    title: 'Decentralized Digital Art Gallery',
    date: 'February 29, 2012',
  },
  {
    image:
      'https://user-images.githubusercontent.com/42206067/231991485-0a8e8c0a-7f51-44b9-8a35-5c7f363c18e1.png',
    title: 'Decentralized Digital Art Gallery',
    date: 'February 29, 2012',
  },
];

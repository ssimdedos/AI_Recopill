import { IBook } from './types';

export const data_book: IBook[] = [
  {
    image:
      'https://user-images.githubusercontent.com/42206067/232230337-a9012621-89d2-4acf-9798-590b5e9f7bb7.png',
    title: 'A Collection of Classic Laser Neon',
  },
  {
    image:
      'https://user-images.githubusercontent.com/42206067/232230304-79f5176c-3fb3-4785-97c0-b24f8d5a6828.png',
    title: 'Decentralized Digital Art Gallery',
  },
  {
    image:
      'https://user-images.githubusercontent.com/42206067/232230330-c754aab5-647f-40cf-951e-0662232ef1bd.png',
    title: 'Browse Through Unique Digital Art',
  },
  {
    image:
      'https://user-images.githubusercontent.com/42206067/232230337-a9012621-89d2-4acf-9798-590b5e9f7bb7.png',
    title: 'A Collection of Classic Laser Neon',
  },
  {
    image:
      'https://user-images.githubusercontent.com/42206067/232230304-79f5176c-3fb3-4785-97c0-b24f8d5a6828.png',
    title: 'Decentralized Digital Art Gallery',
  },
  {
    image:
      'https://user-images.githubusercontent.com/42206067/232230330-c754aab5-647f-40cf-951e-0662232ef1bd.png',
    title: 'Browse Through Unique Digital Art',
  },
];

export interface IBook {
  image: string;
  title: string;
}

export interface IBookmark {
  image: string;
  title: string;
}

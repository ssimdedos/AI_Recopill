export interface IBook {
  image: string;
  name: string;
  time: string;
}

import { IStockHot } from './types';

export const data_stock_hot: IStockHot[] = [
  {
    name: 'Dow Jones',
  },
  {
    name: 'S&P 500',
  },
  {
    name: 'US 30',
  },
];

export interface IStockHot {
  name: string;
}

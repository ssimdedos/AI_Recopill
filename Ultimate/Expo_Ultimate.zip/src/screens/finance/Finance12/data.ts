import { IHistory } from './types';

export const data_histories: IHistory[] = [
  {
    name: 'Ultimate Buy',
    date: 'December 2, 2018',
    label: 'Task',
    point: 130,
  },
  {
    name: 'Daily Check in',
    date: 'December 2, 2018',
    label: 'Survey',
    point: 24,
  },
  {
    name: 'Registration',
    date: 'December 2, 2018',
    label: 'Task',
    point: 68,
  },
  {
    name: 'Refer Friends',
    date: 'December 2, 2018',
    label: 'Task',
    point: 79,
  },
  {
    name: 'Ultimate Buy',
    date: 'December 2, 2018',
    label: 'Task',
    point: 130,
  },
];

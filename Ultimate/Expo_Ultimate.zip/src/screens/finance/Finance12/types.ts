export interface IHistory {
  name: string;
  date: string;
  label: string;
  point: number;
}

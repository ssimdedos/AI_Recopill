export interface IPayout {
  image: string;
  amount: number;
  credits: number;
}

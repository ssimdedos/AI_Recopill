import { IFriend } from './types';

export const data_friends: IFriend[] = [
  {
    avatar:
      'https://user-images.githubusercontent.com/42206067/224560653-d762ceb5-8896-4f2a-840d-5a4d3b3fadf5.png',
    name: 'Christine Stewart',
    time: '2 days ago',
  },
  {
    avatar:
      'https://user-images.githubusercontent.com/42206067/224560653-d762ceb5-8896-4f2a-840d-5a4d3b3fadf5.png',
    name: 'Christine Stewart',
    time: '1 week',
  },
  {
    avatar:
      'https://user-images.githubusercontent.com/42206067/224560653-d762ceb5-8896-4f2a-840d-5a4d3b3fadf5.png',
    name: 'Christine Stewart',
    time: '2 months',
  },
];

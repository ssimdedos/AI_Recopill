export interface IFriend {
  avatar: string;
  name: string;
  time: string;
}

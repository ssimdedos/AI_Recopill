export interface ITask {
  image: string;
  name: string;
  description: string;
  label: string;
  point: number;
}

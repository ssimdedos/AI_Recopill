export interface ICategory {
  color: string;
  image: string;
}

export interface IStock {
  category: ICategory;
}

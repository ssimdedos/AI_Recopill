export interface IAnswer {
  id: number;
  description: string;
}
